# please follow the semver semantics, i.e. MAJOR.MINOR.PATCH where
# MAJOR: incompatible API changes
# MINOR: add backwards-compatible functionality
# PATCH: backwards-compatible bug fixes.
__version__ = '3.2.0'
